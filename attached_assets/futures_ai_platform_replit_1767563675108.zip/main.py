# Entry point placeholder – wire scheduler + agents here
print('Futures AI platform scaffold loaded')
