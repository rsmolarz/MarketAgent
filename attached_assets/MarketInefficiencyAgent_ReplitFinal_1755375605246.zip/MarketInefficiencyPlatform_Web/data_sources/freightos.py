
def get_shipping_index():
    # Simulated freight index (e.g. from Freightos)
    return 7400
