
def get_insider_buy_counts():
    # Simulated insider buy counts by ticker
    return {"MSFT": 8, "AMZN": 2, "NFLX": 12}
