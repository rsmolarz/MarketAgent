
def get_etf_flows():
    return {"SPY": -1.4e9, "ARKK": 600e6}
