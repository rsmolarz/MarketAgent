
def get_asset_correlation():
    return 0.04  # Simulated correlation
