
def get_short_interest():
    # Simulated short interest
    return {"GME": 24.5, "AMC": 18.7, "TSLA": 3.5}
