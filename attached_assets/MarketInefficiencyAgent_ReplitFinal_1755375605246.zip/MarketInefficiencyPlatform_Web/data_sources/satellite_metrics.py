
def get_tanker_count():
    return 140  # Simulated visible tankers
