
def get_sentiment_and_price():
    return {"sentiment": 4.7, "price_change": -3.1}
