
def get_regulatory_headlines():
    return ["SEC charges insider trading ring", "CFTC fines firm $100M"]
