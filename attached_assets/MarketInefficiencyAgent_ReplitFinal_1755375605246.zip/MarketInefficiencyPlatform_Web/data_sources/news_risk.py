
def get_geopolitical_risk_index():
    # Simulated geopolitical risk index
    return 8.6
