NEWS_API_KEY = ""              # optional (NewsAPI). If blank, uses Google News RSS
ALPHA_VANTAGE_API_KEY = ""     # optional (market context)
HOTSPOTS = {
    "Taiwan": "Taiwan China",
    "Ukraine": "Ukraine Russia",
    "Middle East": "Israel Gaza",
    "China-US": "China US conflict"
}
RISK_THRESHOLD = 50
MAX_ARTICLES_PER_REGION = 5
MAX_RETRIES = 3
CACHE_SIZE = 100
LOG_LEVEL = "INFO"
MARKET_SYMBOLS = ["SPY"]
