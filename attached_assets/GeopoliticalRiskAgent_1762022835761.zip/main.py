import json
from geopolitical_risk_agent.agent import GeopoliticalRiskAgent

if __name__ == "__main__":
    agent = GeopoliticalRiskAgent()
    alerts_json, alerts_text = agent.run()
    print("JSON Output:")
    print(json.dumps(alerts_json, indent=2))
    print("\nFormatted Alerts:")
    print(alerts_text)
