# GeopoliticalRiskAgent (Replit Drop‑In)

Monitors global geopolitical risks via news (NewsAPI or Google News RSS) with NLP-based risk scoring and optional Alpha Vantage market context.

## Install (Replit)
1) Upload all files into your repo (keep folder structure).
2) Secrets (optional): `NEWS_API_KEY`, `ALPHA_VANTAGE_API_KEY` (or edit `config.py`).
3) Install deps and NLTK data:
   ```bash
   pip install -r requirements.txt
   python -c "import nltk; nltk.download('vader_lexicon')"
   ```

## Run
```bash
python main.py
```

## Configure
Edit `config.py` to set hotspots, thresholds, and market symbols.
