import logging
from typing import List, Dict, Tuple
try:
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    _sia = SentimentIntensityAnalyzer()
except Exception:
    logging.error("NLTK VADER not available. Run: python -c \"import nltk; nltk.download('vader_lexicon')\"")
    _sia = None

RISK_KEYWORDS = [
    "war","conflict","attack","military","forces","troops","invasion",
    "sanction","missile","nuclear","crisis","tension","clash","protest",
    "escalation","strike","violence","ceasefire","hostility","terror",
    "bomb","airstrike","shelling","cyberattack"
]

def analyze_articles(articles: List[Dict]) -> Tuple[int, List[str], str]:
    if not articles:
        return 0, [], ""
    total = 0
    kw_freq: Dict[str,int] = {}
    top = []
    for a in articles:
        text = (a.get("text") or "").lower()
        title = a.get("title") or ""
        comp = 0.0
        if _sia:
            try:
                comp = _sia.polarity_scores(text).get("compound", 0.0)
            except Exception:
                comp = 0.0
        risk = 0
        if comp < -0.5: risk += 2
        elif comp < -0.2: risk += 1
        found = {kw for kw in RISK_KEYWORDS if kw in text}
        for kw in found:
            risk += 1
            kw_freq[kw] = kw_freq.get(kw, 0) + 1
        if risk > 0:
            top.append((risk, title))
        total += risk
    total = min(total, 10)
    score = int((total/10)*100)
    summary = ""
    if top:
        top.sort(key=lambda x: x[0], reverse=True)
        picks = [t for _, t in top][:2]
        if picks:
            summary += picks[0].strip()
            if summary and summary[-1] not in ".!?":
                summary += "."
        if len(picks) > 1:
            summary += " " + picks[1].strip()
            if summary and summary[-1] not in ".!?":
                summary += "."
    keywords = []
    if kw_freq:
        for kw, _ in sorted(kw_freq.items(), key=lambda x: (-x[1], x[0]))[:5]:
            keywords.append(kw.capitalize())
    return score, keywords, summary
