import logging, requests
from datetime import datetime
from typing import Dict, List, Tuple
from . import collectors, analysis
from config import HOTSPOTS, NEWS_API_KEY, ALPHA_VANTAGE_API_KEY, RISK_THRESHOLD, MAX_ARTICLES_PER_REGION, MAX_RETRIES, CACHE_SIZE

class GeopoliticalRiskAgent:
    def __init__(self):
        self.seen_titles: Dict[str, List[str]] = {r: [] for r in HOTSPOTS}
        level = getattr(__import__('config'), 'LOG_LEVEL', 'INFO')
        logging.basicConfig(level=getattr(logging, str(level).upper(), logging.INFO),
                            format="%(asctime)s [%(levelname)s] %(message)s")
        logging.info("GeopoliticalRiskAgent initialized.")

    def fetch_and_analyze(self) -> List[Dict]:
        alerts = []
        for region, query in HOTSPOTS.items():
            logging.info(f"Checking region: {region}")
            arts = []
            for attempt in range(MAX_RETRIES):
                arts = collectors.fetch_news_articles(query, api_key=NEWS_API_KEY, max_results=MAX_ARTICLES_PER_REGION)
                if arts or attempt == MAX_RETRIES-1: break
                logging.warning(f"No articles for {region} (try {attempt+1}); retrying...")
            if not arts:
                logging.info(f"No articles for {region}.")
                continue
            new_arts = [a for a in arts if a.get("title") and a["title"] not in self.seen_titles[region]]
            for a in new_arts:
                t = a.get("title","")
                if t:
                    self.seen_titles[region].append(t)
                    if len(self.seen_titles[region]) > CACHE_SIZE:
                        self.seen_titles[region] = self.seen_titles[region][-CACHE_SIZE:]
            if not new_arts:
                logging.info(f"No new articles for {region}.")
                continue
            score, keywords, summary = analysis.analyze_articles(new_arts)
            logging.info(f"{region} risk score: {score}")
            if score >= RISK_THRESHOLD:
                alerts.append({
                    "region": region,
                    "risk_score": score,
                    "keywords": keywords,
                    "summary": summary,
                    "timestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
                })
                logging.warning(f"ALERT: {region} risk {score} >= threshold {RISK_THRESHOLD}")
        return alerts

    def integrate_market(self, alerts: List[Dict]) -> List[Dict]:
        if not ALPHA_VANTAGE_API_KEY or not alerts:
            return alerts
        try:
            from config import MARKET_SYMBOLS
            symbols = MARKET_SYMBOLS
        except Exception:
            symbols = ["SPY"]
        info = {}
        for sym in symbols:
            try:
                r = requests.get("https://www.alphavantage.co/query",
                                 params={"function":"GLOBAL_QUOTE","symbol":sym,"apikey":ALPHA_VANTAGE_API_KEY},
                                 timeout=10)
                if r.status_code == 200:
                    d = r.json().get("Global Quote", {})
                    price = d.get("05. price"); chg = d.get("10. change percent")
                    if price:
                        info[sym] = {"price": price, "change_percent": chg}
                else:
                    logging.error(f"AV HTTP {r.status_code} for {sym}")
            except Exception as e:
                logging.error(f"AV fetch error for {sym}: {e}")
        for a in alerts:
            a["market_data"] = info
        return alerts

    def format_alerts(self, alerts: List[Dict]) -> str:
        if not alerts:
            return "No significant geopolitical risks detected at the moment."
        lines = []
        for i, a in enumerate(alerts):
            line = f"**{a['region']}:** {a['summary']}"
            if a.get("keywords"):
                line += f" (Keywords: {', '.join(a['keywords'])})"
            line += f" – *Risk Score: {a['risk_score']}/100*"
            if a.get("market_data") and i == 0:
                parts = []
                for sym, d in a["market_data"].items():
                    if d.get("price"):
                        parts.append(f"{sym}: {d['price']} ({d.get('change_percent')})")
                if parts:
                    line += " – Market data: " + ", ".join(parts)
            lines.append(line)
        return "\n".join(lines)

    def run(self) -> Tuple[Dict, str]:
        logging.info("Running GeopoliticalRiskAgent...")
        alerts = self.fetch_and_analyze()
        alerts = self.integrate_market(alerts)
        out_json = {"alerts": alerts}
        out_text = self.format_alerts(alerts)
        logging.info("Done.")
        return out_json, out_text
