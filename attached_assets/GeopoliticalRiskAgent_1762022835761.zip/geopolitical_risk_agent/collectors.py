import requests, feedparser, logging, urllib.parse, re
from typing import List, Dict

def fetch_news_articles(query: str, api_key: str = None, max_results: int = 5) -> List[Dict]:
    """Fetch recent news for a query via NewsAPI (if api_key) or Google News RSS."""
    arts = []
    try:
        if api_key:
            url = "https://newsapi.org/v2/everything"
            params = {"q": query, "language": "en", "sortBy": "publishedAt", "pageSize": max_results}
            headers = {"Authorization": f"Bearer {api_key}"}
            logging.debug(f"NewsAPI fetch: {query}")
            r = requests.get(url, params=params, headers=headers, timeout=10)
            if r.status_code != 200:
                logging.error(f"NewsAPI HTTP {r.status_code}: {r.text}")
            r.raise_for_status()
            data = r.json()
            for a in data.get("articles", [])[:max_results]:
                title = (a.get("title") or "").strip()
                desc = (a.get("description") or a.get("content") or title or "").strip()
                combined = f"{title}. {desc}".strip()
                arts.append({"title": title, "text": combined})
        else:
            rss_url = f"https://news.google.com/rss/search?q={urllib.parse.quote(query)}&hl=en-US&gl=US&ceid=US:en"
            logging.debug(f"Google News RSS fetch: {query}")
            feed = feedparser.parse(rss_url)
            for entry in feed.entries[:max_results]:
                title = getattr(entry, "title", "") or ""
                summary = getattr(entry, "summary", "") or ""
                summary = re.sub('<[^<]+?>', '', summary)
                text = (summary or title).strip()
                arts.append({"title": title.strip(), "text": text})
    except Exception as e:
        logging.error(f"fetch_news_articles error for '{query}': {e}")
    return arts
