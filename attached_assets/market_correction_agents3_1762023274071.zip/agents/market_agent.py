from .base_agent import BaseAgent

class MarketAgent(BaseAgent):
    def __init__(self):
        super().__init__("MarketAgent")
    def run(self):
        self.log("Running MarketAgent...")
        return {"status": "ok"}
