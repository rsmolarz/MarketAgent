from agents.market_agent import MarketAgent

if __name__ == "__main__":
    agent = MarketAgent()
    signals = agent.run()
    print("Final signals:", signals)
