# Market Correction Monitoring Agents (Replit Install Guide)

## Installation

1. Upload the contents of this zip into your Replit project.
2. Run `pip install -r requirements.txt` in the Replit shell.
3. Add environment variables in `config/example.env` to Replit Secrets.
4. Import and run:
   ```python
   from agents.market_agent import MarketAgent
   agent = MarketAgent()
   signals = agent.run()
   ```
