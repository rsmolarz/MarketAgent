# Distressed Investing Platform
## Institutional-Grade Distressed Debt Analysis & Portfolio Management

A comprehensive platform for distressed debt investing, implementing frameworks from Moyer's "Distressed Debt Analysis" textbook.

---

## 🏗️ Architecture

```
distressed_investing_platform/
├── agents/                          # AI Analysis Agents
│   ├── distressed_deal_evaluator_agent.py    # Main analysis agent (1,563 lines)
│   ├── distressed_property_agent.py          # Real estate distressed analysis
│   └── scheduler_integration.py              # Automated scheduling
│
├── data_feeds/                      # Market Data Integration
│   └── feed_manager.py              # Unified feed manager
│       ├── DebtwireFeed             # Deal flow intelligence
│       ├── BloombergFeed            # Market data & pricing
│       ├── PACERFeed                # Court filings
│       ├── SECEdgarFeed             # SEC filings
│       ├── NewsFeed                 # News & sentiment
│       └── TradeClaimFeed           # Trade claim platforms
│
├── backtesting/                     # Strategy Backtesting
│   └── backtest_engine.py           # Historical testing engine
│       ├── HistoricalCaseDatabase   # 10 major bankruptcies
│       ├── Strategy framework       # Signal-based strategies
│       └── Monte Carlo simulation   # Robustness testing
│
├── portfolio/                       # Portfolio & Risk Management
│   └── portfolio_manager.py         # Position & risk tracking
│       ├── Portfolio                # Position management
│       ├── RiskLimits               # Configurable limits
│       ├── StressTest               # Scenario analysis
│       └── Alerts                   # Risk alerts
│
├── dashboard/                       # Web Dashboard
│   ├── api.py                       # FastAPI backend
│   └── index.html                   # Interactive frontend
│
├── eval/                            # Evaluation Framework
│   └── adapters_distressed.py       # Agent evaluation adapters
│
├── run_platform.py                  # Main entry point
└── requirements.txt                 # Python dependencies
```

---

## 🚀 Quick Start

### Installation

```bash
# Install dependencies
pip install -r requirements.txt

# For full dashboard support
pip install fastapi uvicorn
```

### Run Demo

```bash
# Portfolio management demo
python run_platform.py demo

# Backtesting historical bankruptcies
python run_platform.py backtest

# Start dashboard API server
python run_platform.py api

# Run all demos
python run_platform.py all
```

### Open Dashboard

After running `python run_platform.py api`:
- API: http://localhost:8000
- Docs: http://localhost:8000/docs
- Dashboard: Open `dashboard/index.html` in browser

---

## 📊 Components

### 1. Data Feeds (`data_feeds/feed_manager.py`)

Unified interface for multiple data sources:

| Feed | Source | Data Type |
|------|--------|-----------|
| DebtwireFeed | Debtwire/Reorg | Deal flow, restructuring intel |
| BloombergFeed | Bloomberg/Refinitiv | Bond prices, yields, ratings |
| PACERFeed | PACER | Bankruptcy court filings |
| SECEdgarFeed | SEC EDGAR | 8-K, 10-K, 10-Q filings |
| NewsFeed | News API | News with sentiment scoring |
| TradeClaimFeed | Claim platforms | Vendor/trade claims |

**Configuration via environment variables:**
```bash
export DEBTWIRE_API_KEY=your_key
export BLOOMBERG_API_KEY=your_key
export PACER_API_KEY=your_key
export NEWS_API_KEY=your_key
```

**Usage:**
```python
from data_feeds.feed_manager import FeedManager

fm = FeedManager()

# Fetch distressed deals
deals = fm.fetch_deals(status="bankruptcy", sector="retail")

# Get aggregated company data
data = fm.aggregate_company_data("Hertz Global", ticker="HTZ")
```

---

### 2. Backtesting (`backtesting/backtest_engine.py`)

Test strategies against historical bankruptcies.

**Historical Cases (10 major cases):**
- Enron (2001) - Energy fraud
- Lehman Brothers (2008) - Financial crisis
- General Motors (2009) - Auto bailout
- Toys R Us (2017) - Retail apocalypse
- Hertz (2020) - COVID-19 (rare equity recovery!)
- PG&E (2019) - Wildfire liabilities
- J.Crew (2020) - COVID retail
- Caesars (2015) - Gaming
- Sears (2018) - Retail decline
- Washington Mutual (2008) - Bank failure

**Built-in Strategies:**

| Strategy | Description | Signal |
|----------|-------------|--------|
| Fulcrum Hunter | Buy at capital structure pivot | Recovery ≈ EV |
| Deep Value | Deeply discounted seniors | Price < 40, coverage > 50% |
| Z-Score Contrarian | Buy cheap in low Z companies | 0.3 < Z < 1.5, price < 50 |

**Usage:**
```python
from backtesting.backtest_engine import BacktestEngine, create_fulcrum_strategy

engine = BacktestEngine(initial_capital=10_000_000)
strategy = create_fulcrum_strategy()

# Run backtest
result = engine.run_backtest(strategy, start_date="2001-01-01", end_date="2023-12-31")

print(f"Total Return: {result.total_return*100:.1f}%")
print(f"Sharpe Ratio: {result.sharpe_ratio:.2f}")
print(f"Max Drawdown: {result.max_drawdown*100:.1f}%")

# Monte Carlo simulation
mc = engine.run_monte_carlo(strategy, n_simulations=1000)
print(f"Return 5th-95th percentile: {mc['return_5th_pct']*100:.1f}% to {mc['return_95th_pct']*100:.1f}%")
```

---

### 3. Portfolio Management (`portfolio/portfolio_manager.py`)

Full position and risk management system.

**Features:**
- Position tracking with mark-to-market
- Real-time P&L (realized + unrealized)
- Risk limits enforcement
- Exposure analysis (sector, seniority, status)
- VaR and Expected Shortfall
- Stress testing (5 default scenarios)
- Alert system

**Risk Limits (configurable):**
```python
RiskLimits(
    max_single_position_pct=0.10,     # 10% max single position
    max_single_issuer_pct=0.15,       # 15% max single issuer
    max_sector_exposure_pct=0.25,     # 25% max per sector
    max_subordinated_pct=0.30,        # 30% max subordinated
    max_equity_pct=0.10,              # 10% max equity
    max_bankruptcy_pct=0.50,          # 50% max in bankruptcy
    max_portfolio_var_pct=0.15,       # 15% max daily VaR
    max_drawdown_pct=0.25,            # 25% drawdown trigger
)
```

**Usage:**
```python
from portfolio.portfolio_manager import Portfolio, Position, SecurityType, RiskLimits

# Create portfolio
portfolio = Portfolio("main", initial_capital=10_000_000, risk_limits=RiskLimits())

# Add position
position = Position(
    position_id="pos_1",
    company_name="Hertz Global",
    company_id="hertz",
    security_type=SecurityType.SENIOR_UNSECURED,
    security_id="HTZ_5.5_2024",
    face_amount=2_000_000,
    entry_price=40,
    entry_date="2024-01-15",
    industry="transportation",
    case_status="bankruptcy",
    recovery_estimate=100,
)
success, msg = portfolio.add_position(position)

# Update marks
portfolio.update_marks({"HTZ_5.5_2024": 65})

# Get reports
snapshot = portfolio.take_snapshot()
exposure = portfolio.get_exposure_report()
risk = portfolio.get_risk_report()

# Run stress test
results = portfolio.run_stress_test(portfolio.get_default_stress_scenarios())
```

---

### 4. Dashboard (`dashboard/`)

Interactive web dashboard with FastAPI backend.

**API Endpoints:**

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/portfolio/summary` | GET | Portfolio summary |
| `/api/portfolio/positions` | GET | All positions |
| `/api/portfolio/positions` | POST | Add position |
| `/api/portfolio/positions/{id}` | DELETE | Close position |
| `/api/portfolio/update-marks` | POST | Update prices |
| `/api/portfolio/exposure` | GET | Exposure breakdown |
| `/api/portfolio/risk` | GET | Risk metrics |
| `/api/portfolio/stress-test` | POST | Run stress test |
| `/api/alerts` | GET | Risk alerts |
| `/api/deals` | GET | Deal pipeline |
| `/api/filings` | GET | Court filings |
| `/api/news` | GET | Company news |
| `/api/claims` | GET | Trade claims |
| `/api/backtest/run` | POST | Run backtest |
| `/api/backtest/cases` | GET | Historical cases |

**Frontend Features:**
- Real-time NAV and P&L tracking
- Position management
- Exposure charts (sector, seniority)
- Risk metrics dashboard
- Stress test visualization
- Backtesting interface
- Historical case browser

---

### 5. Analysis Agents (`agents/`)

AI-powered analysis implementing Moyer frameworks:

**DistressedDealEvaluatorAgent (1,563 lines):**
- EBITDA normalization (Ch. 5)
- Multiple derivation from DCF (Table 5-4)
- Liquidation analysis by asset class
- Credit capacity analysis (Tables 6-1 to 6-5)
- Cash flow volatility assessment
- Capital structure hierarchy (Figure 7-1)
- Plan vs true value scenarios (Ch. 10)
- Recovery waterfall with absolute priority
- Capital structure arbitrage detection
- Legal risk assessment (Ch. 11)
- Due diligence framework

---

## 📈 Example Output

### Portfolio Demo
```
NAV:              $10,915,000
Cash:             $8,295,000
Gross Exposure:   $2,620,000
Positions:        3
P&L:              $915,000 (+9.2%)

Stress Test - 2008 Crisis: -$746K (-6.8%)
Stress Test - Recovery Rally: +$484K (+4.4%)
```

### Backtest Results
```
Strategy: Fulcrum Hunter
Total Return: 156.2%
Annualized: 12.8%
Sharpe Ratio: 1.45
Win Rate: 68.5%
Max Drawdown: 28.5%
```

---

## 🔧 Configuration

### Environment Variables

```bash
# Data Feeds
DEBTWIRE_API_URL=https://api.debtwire.com/v1
DEBTWIRE_API_KEY=your_key

BLOOMBERG_API_URL=https://api.bloomberg.com/v1
BLOOMBERG_API_KEY=your_key

PACER_API_URL=https://pcl.uscourts.gov/api
PACER_API_KEY=your_key

NEWS_API_URL=https://newsapi.org/v2
NEWS_API_KEY=your_key

SEC_EDGAR_URL=https://data.sec.gov
SEC_USER_AGENT=YourCompany/1.0

TRADE_CLAIMS_API_URL=https://api.claims-platform.com
TRADE_CLAIMS_API_KEY=your_key
```

---

## 📚 References

- Moyer, S.G. "Distressed Debt Analysis: Strategies for Speculative Investors"
- Altman, E. "Corporate Financial Distress and Bankruptcy"
- Bankruptcy Code (11 U.S.C.)
- PACER (Public Access to Court Electronic Records)

---

## 📄 License

For educational and research purposes.

---

## 🤝 Contributing

This platform is designed to be extended. Key areas for contribution:
- Additional data feed integrations
- New backtesting strategies
- Enhanced risk models
- UI/UX improvements
